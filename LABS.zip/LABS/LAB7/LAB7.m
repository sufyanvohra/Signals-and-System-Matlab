load Part2
% figure
% plot(t,r)
% title('Plot of r(t) against t');
% xlabel('t');
% ylabel('r(t)');
R=FT(r);
% figure
% plot(omega,abs(R));
% title('Magnitude of R(w) against w ');
% xlabel('w'); 
% ylabel('|R{w)|');
%soundsc(r,20000);
fc1 = 157100/(2*pi);
fc2 = 251300/(2*pi);
fc3 = 345600/(2*pi);
ListenToMyRadio(r,40000,t,omega);

%%
function []= ListenToMyRadio(r,fc,t,omega)
    d = r.*cos(2*pi*fc*t);
%     figure
%     plot(t,d);
%     title(' Plot of d(t) ');
%     xlabel('t'); 
%     ylabel('d(t)');
    B = 2*pi*8200;
    D = FT(d);
%     figure
%     plot(omega,abs(D));
%     title('Magnitude of D(w)');
%     xlabel('w'); 
%     ylabel('D(w)');
    M = zeros(1,length(D));
    for i = 1:length(omega)
        if(omega(i) < 2*pi*4100 && omega(i) > -2*pi*4100)
           M(i) = D(i);   
        end   
    end
    figure
%     plot(omega,abs(M));
%     title('Magnitude of M(w) against w ');
%     xlabel('w'); 
%     ylabel('M(w)');
    figure
    m=IFT(M);
%     plot(t,m);
%     title('plot 0f m(t)');
%     xlabel('t'); 
%     ylabel('M(t)');
    soundsc(m,200000);
end


