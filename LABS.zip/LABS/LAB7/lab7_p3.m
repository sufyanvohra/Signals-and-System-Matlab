load Part2
R=FT(r);
W = zeros(1,length(R));
    for i = 1:length(omega)
        if(omega(i)-2*pi*40000 <= 2*pi*4100 && omega(i)-2*pi*40000 >= -2*pi*4100)
           W(i) = R(i);
           W(length(W)-i) =  R(length(R)-i);
        end   
    end
% figure
% plot(omega,abs(W));
% title('Magnitude of Fourier Transform of W');
% xlabel('w'); 
% ylabel('W(w)');
w = IFT(W);
ListenToMyRadio(w,40000,t,omega);
% w = -pi:pi/30:pi
% X = (2*sin(3*(w-2*pi)))./(w-2*pi);
% figure
% plot(w,20*log10(X))
% LOW PASS FILTER
Q = zeros(1,length(W));
    for i = 1:length(omega)
        if(omega(i) < 2*pi*40000 && omega(i)> -2*pi*40000)
           Q(i) = W(i);
        end   
    end
q = IFT(Q);
%%
figure
plot(t,q)
figure
plot(omega,abs(W));
title(' Plot of Magnitude of Q(w) ');
xlabel('w'); 
ylabel('Q(w)');

ListenToMyRadio(q,40000,t,omega);

figure
plot(omega,abs(Q));
title(' Plot of Magnitude of Q(w) ');
xlabel('w'); 
ylabel('Q(w)');
function []= ListenToMyRadio(r,fc,t,omega)
    d = r.*cos(2*pi*fc*t);
%     figure
%     plot(t,d);
% %     title(' Plot of d(t) ');
% %     xlabel('t'); 
% %     ylabel('d(t)');
    B = 2*pi*8200;
    D = FT(d);
%     figure
%     plot(omega,abs(D));
%     title('Magnitude of D(w)');
%     xlabel('w'); 
%     ylabel('D(w)');
    M = zeros(1,length(D));
    for i = 1:length(omega)
        if(omega(i) < 2*pi*4100 && omega(i) > -2*pi*4100)
           M(i) = D(i);   
        end   
    end
%     figure
%     plot(omega,abs(M));
%     title('Magnitude of M(w) against w ');
%     xlabel('w'); 
%     ylabel('M(w)');
%     figure
    m=IFT(M);
%     plot(t,m);
%     title('plot 0f m(t)');
%     xlabel('t'); 
%     ylabel('M(t)');
    soundsc(m,200000);
end