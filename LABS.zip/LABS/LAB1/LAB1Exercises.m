
%Part 2

%part b

 t=[0:1/8192:1];
 f0 = 493.88;

 x1 = cos(2*pi*f0*t);
 figure 
 plot(t,x1); %plottinf x1 versus t
xlabel('t');
ylabel(' X1 ');
title('Sound Signal x1');

 sound(x1);
 pause(2);
 sound(x1);

 % part c
 
f0 = 587.33;
x1 = cos(2*pi*f0*t);
 sound(x1);
 pause(2);
 sound(x1);
 
 % part d
 
 f0 = 880;
 x1 = cos(2*pi*f0*t);
 sound(x1);
 pause(2);
 sound(x1);
 
 %%
  t=[0:1/8192:1];

  f0 = 493.88;
  a = 8;
x2 = exp(-a*t).*cos(2*pi*f0*t);
figure
plot(t,x2);
xlabel('t');
ylabel(' X2 ');
title('Sound Signal x2 with f0 = 493.88,a = 8');
sound(x2);

%%
  t=[0:1/8192:1];
  f0 = 493.88;
  f1 = 8;
x3 = cos(2*pi*f1*t) .* cos(2*pi*f0*t);
figure
plot(t,x3)
xlabel('t');
ylabel(' X3 ');
title('Sound Signal x3 with f0 = 493.88,f1 = 8');
sound(x3);



%% part 3

t=[0:1/8192:1];
a = 1949;
x4 = cos(pi*a*t.^2);
sound(x4);

%%
t=[0:1/8192:2];
x5 = cos(2*pi*(-250*t.^2 +800*t+4000));
sound(x5);


%% part 4
t=[0:1/8192:1];
a =1949;
phi = 0;
x6 = sin(2*pi*a*t+ phi);
sound(x6);
%%




