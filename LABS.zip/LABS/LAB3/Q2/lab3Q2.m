
Fs = 8192 ; 
nBits = 16 ; 
nChannels = 2 ; 
ID = 1; % default audio input device 
recObj = audiorecorder(Fs,nBits,ID);
% Collect a five second sample of your speech with your microphone.

disp('Start speaking.');
recordblocking(recObj,10);
disp('End of Recording.');
x = getaudiodata(recObj);
t = 0:1/8192:10-1/8192;
sound(x,8192);
figure
plot(t,x);
xlabel('t/s');
ylabel('amp');
title('Sound signal')

l = length(x);
x = transpose(x);
x1 = [zeros(1,0.5*8172) 0.35*x(1,1:l-0.5*8172)];
x2 = [zeros(1,1.25*8172) 0.5*x(1,1:l-1.25*8172)];
x3 = [zeros(1,2.5*8172) 0.65*x(1,1:l-2.5*8172)];
x4 = [zeros(1,3*8172) 0.05*x(1,1:l-3*8172)];
x5 = [zeros(1,2.75*8172) 0.15*x(1,1:l-2.75*8172)];


 y = x + x1 + x2 + x3 + x4 + x5;
figure
plot(t,y);
xlabel('t/s');
ylabel('amp');
title(' Echoed Sound signal');
sound(y,8192);
omega=linspace(-8192*pi,8192*pi,81921);
omega=omega(1:81920);
%%
Y = FT(y);  
X = FT(x);

H = Y./X;
figure
plot(omega,abs(H));
xlabel('w');
ylabel('amp');
title('Frequency Response H(w)');

h=IFT(H)
figure
plot(t,h)
xlabel('t/s');
ylabel('amp');
title('Impulse Response');

Xe = Y./H
xe=IFT(Xe)
plot(t,xe);
xlabel('t/s');
ylabel('amp');
title('estimated speech');
sound(xe,8192);

