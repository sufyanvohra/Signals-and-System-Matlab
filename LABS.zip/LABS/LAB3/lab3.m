 x = DTMFTRA([9 2 0 1]);
 soundsc(x,8192)
 
 X=FT(x);
 
omega=linspace(-8192*pi,8192*pi,8193);
omega=omega(1:8192);
figure

plot(omega,abs(X));
xlabel('omega');
ylabel('Amp');
title('Fourier Transform Magnitude')



%% part 1.2
%analytical expression for analog signal
rec = [ones(1,0.25*8192) zeros(1,0.75*8192)]
plot(rec)
x1t = x.*rec; 
X1t= FT(x1t);
figure 
plot(omega,abs(X1t));
xlabel('omega');
ylabel('Amp');
title('Fourier Transform Magnitude of x1')
rec2 = [zeros(1,0.25*8192) ones(1,0.25*8192) zeros(1,0.5*8192)]
x2t = x.*rec2; 
X2t= FT(x2t);
figure 
plot(omega,abs(X2t));
xlabel('omega');
ylabel('Amp');
title('Fourier Transform Magnitude of x2')
rec3 = [zeros(1,0.50*8192) ones(1,0.25*8192) zeros(1,0.25*8192)]
x3t = x.*rec3; 
X3t= FT(x3t);
figure 
plot(omega,abs(X3t));
xlabel('omega');
ylabel('Amp');
title('Fourier Transform Magnitude of x3')
rec4 = [zeros(1,0.75*8192) ones(1,0.25*8192)]
x4t = x.*rec4; 
X4t= FT(x4t);
figure 
plot(omega,abs(X4t));
xlabel('omega');
ylabel('Amp');
title('Fourier Transform Magnitude of x4')











%%
function [X] = DTMFTRA(numb)
N = length(numb);
% Column  and row represents number combinations for 0-9
column = [1136 1209 1336 1447 1209 1336 1447 1209 1336 1447];
row = [941 697 697 697 770 770 770 852 852 852];
X =zeros(1,N*8192*0.25);

cons = 8192;
for i = 1:N
    for b = (i-1)*0.25:(1/cons):i*0.25-(1/cons)
        X(b*cons+1) = cos(2*pi*b*column(numb(i)+1)) + cos(2*pi*b*row(numb(i)+1));
    end
end
end





