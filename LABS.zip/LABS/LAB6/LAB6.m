% %LAB6
% %part2a
D = 21701079;
D5 = rem(D,6);
M = 4 + D5;
b = zeros(1,M);
for k = 1:M
    b(k) = exp(-(k-1));
end
% Ny = 11;
% x  = zeros(1,Ny);
a  = zeros(1,2);
x(1) = 1;
% y=DTLTI(a,b,x,Ny);
% figure
% stem(y)
% title('Impulse response h[n]');
% ylabel('Amplitude')
% xlabel('n'); 
% figure
% stem(b)
% %part 2c
% m = 0;
% f = -pi:pi/30:pi;
% h = zeros(1,length(f));
% 
% for t = 1:length(f)
%   m = 0;
%  for k = 1:M
%      m = m + b(k)*exp(-1j*f(t)*(k));
%  end
%  h(t) = abs(m);
% end
% 
% figure
% plot(f,20*log((h)));
% title('Magnitude response of the Impulse Response');
% ylabel('Magnitude')
% xlabel('f'); 
%%

f0 = 0;
fs = 2000;
Ts = 1/fs;
t = 0:Ts:1;
f_ins = 1000.*t;
Ny_1= 2001
Ny_2 = 20001
Ny_3 = 200001
fs = 2000;
Ts = 1/fs;

t_2 = 0:Ts:10;
t_3 = 0:Ts:100;


phi = 500.*t.*t;
phi_2 = 50.*t_2.*t_2;
phi_3 = 5.*t_3.*t_3;

x_1 = cos(2*pi.*phi);
x_2 = cos(2*pi.*phi_2);
x_3 = cos(2*pi.*phi_3);

w = 0:pi/2000:pi;
w_2 = 0:pi/20000:pi;
w_3 = 0:pi/200000:pi;

y_1 = DTLTI(a,b,x_1,Ny_1);
y_2 = DTLTI(a,b,x_2,Ny_2);
y_3 = DTLTI(a,b,x_3,Ny_3);

subplot(3,3,1)
plot(w,x_1);
title('Chirp Signal x(t) = cos(2??(t))');
xlabel('w');
ylabel('x(t)');

subplot(3,3,4)
plot(w,y_1);
title('Chirp Signal filtered');
xlabel('w');
ylabel('y1');

subplot(3,3,7)
plot(w,20*log10(abs(y_1)));
title('Frequency Response of Chirp Signal');
xlabel('w');
ylabel('Magnitude');

subplot(3,3,2)
plot(w_2,x_2);
title('Chirp Signal x2(t) = cos(2??(t))');
xlabel('w2');
ylabel('x2 ');

subplot(3,3,5)
plot(w_2,y_2);
title('Chirp Signal filtered');
xlabel('w');
ylabel('y2');

subplot(3,3,8)
plot(w_2,20*log10(abs(y_2)));
title('Frequency Response of Chirp2 Signal');
xlabel('w');
ylabel('Amplitude');

subplot(3,3,3)
plot(w_3,x_3);
title('Chirp Signal x3(t) = cos(2??(t))');
xlabel('w');
ylabel('x3(t)');

subplot(3,3,6)
plot(w_3,y_3);
title( ' Chirp Signal filtered ');
xlabel('w');
ylabel('y3');

subplot(3,3,9)
plot(w_3,20*log10(abs(y_3)));
title('Frequency Response of Chirp3 Signal');
xlabel('w');
ylabel('Magnitude');


%% PART-4
id = [2 1 7 0 1 0 7 9];
n = 3 + id;
z1 = (n(1) + (j)*n(8))/sqrt((n(1)^2) + (n(8)^2));
p1 = (n(3) + (j)*n(6))/sqrt(1 + (n(3)^2) + (n(6)^2));
p2 = (n(4) + (j)*n(5))/sqrt(1 + (n(4)^2) + (n(5)^2));
w = -pi:pi/30:pi;
H = (exp(j.*w) - z1)./((exp(j.*w) -  p1).*(exp(j.*w)  - p2));
figure
plot(w,abs(H));
title(' Discrete Time Fourier Transform');
ylabel('Amplitude')
xlabel('w'); 
%% PArt4

f0 = -500;
fs = 1000;
Ts = 1/fs;
t = 0:Ts:1;
t_2 = 0:Ts:10;
t_3 = 0:Ts:1000;

% f_ins = f0 + 1000.*t;
% phi = 500.*t + 500.*t.*t;
% x2 = exp(2*j*pi.*phi);

Ny_1 = 1001;
Ny_2 = 10001;
Ny_3 = 1000001;

phi = (500.*t.*t) + (500.*t);
phi_2 = (50.*t_2.*t_2) + (500.*t_2);
phi_3 = (0.5.*t_3.*t_3) + (500.*t_3);

x_1 = exp(1j*2*pi.*phi);
x_2 = exp(1j*2*pi.*phi_2);
x_3 = exp(1j*2*pi.*phi_3);

w = -pi:pi/500:pi;
w_2 = -pi:pi/5000:pi;
w_3 = -pi:pi/500000:pi;

% Ny = 1001
% w = -pi:pi/500:pi;
b =[0 1 -1*exp(0.62*j)];
% y_2 = DTLTI(a,b,x2,Ny);
% figure
% plot(w,x2);
% figure
% plot(w,y_2);

a1 = 1.78*exp(1j* 0.62);
a2 = 0.97*exp(1.27*1j);
a = [a1 a2];
b0 = 0;
b1 = 1;
b2 = -1*exp(0.62*1j);
b = [b0 b1 b2];
% 
% b0 = 0;
% b1 = 1;
% b2 = 1*exp(1j*1.44);
% b = [b0 b1 b2];
y_1 = DTLTI(a,b,x_1,Ny_1);
y_2 = DTLTI(a,b,x_2,Ny_2);
y_3 = DTLTI(a,b,x_3,Ny_3);

subplot(3,3,1)
plot(w,x_1);
xlim([-pi pi]);
title('Chirp Signal x1(t) = exp(j2??(t))');
xlabel('w');
ylabel('x');

subplot(3,3,4)
plot(w,y_1);
xlim([-pi pi]);
title('Chirp Signal filtered');
xlabel('w');
ylabel('y_1');

subplot(3,3,7)
plot(w,angle(y_1));
xlim([-pi pi]);
title('Chirp Signal Phase');
xlabel('w');
ylabel('Phase');

subplot(3,3,2)
plot(w_2,x_2);
xlim([-pi pi]);
title('Chirp Signal x2(t) = exp(j2??(t))');
xlabel('w2');
ylabel('x2');

subplot(3,3,5)
plot(w_2,y_2);
xlim([-pi pi]);
title('Chirp Signal filtered');
xlabel('w2');
ylabel('y2');

subplot(3,3,8)
plot(w_2,(angle(y_2)));
xlim([-pi pi]);
title('Chirp Signal Phase');
xlabel('w2');
ylabel('Phase');
% 
subplot(3,3,3)
plot(w_3,x_3);
xlim([-pi pi]);
title('Chirp Signal x3(t) = exp(j2??(t))');
xlabel('w_3');
ylabel('x3');

subplot(3,3,6)
plot(w_3,y_3);
xlim([-pi pi]);
title('Chirp Signal filtered');
xlabel('w3');
ylabel('y3');

subplot(3,3,9)
plot(w_3,(angle(y_3)));
xlim([-pi pi]);
title('Chirp Signal Phase');
xlabel('w3');
ylabel('Phase');


% PART 1
function [y]=DTLTI(a,b,x,Ny)
 N = length(a);
 M =length(b)-1;
 y = zeros(1,Ny);
 y(1) = b(1)*x(1);
 y(2) = a(1)*b(1)*x(1)*b(1) + b(1)*x(2)+b(2)*x(1);
 for n = 3:Ny 
    for l = 1:N
        c = n-l;
        y(n) = a(l)*y(c);
    end
    for k = 0:M
        if (n-(k+1) <= 0)
           d = 0;
        else
           d = x(n-(k+1));
        end
        y(n) = y(n) + b(k+1)*d;
    end
    
 end
end
function [y] = DTLTI(a,b,x,Ny)
    N = length(a);
    M = length(b) - 1;
    y = zeros(1,Ny);
    y(1) = b(1)*x(1);
    y(2) = a(2)*y(1) + b(1)*x(2) + b(2)*x(1);
    
    for n = 3:Ny
        for l = 1:N
            if n-l <= 0
                d = 0;
            else
                d = y(n-l);
            end
            y(n) = a(l)*d;
        end
    
        for k = 0:M
            if n-(k+1) <= 0
                c = 0;
            else
                c = x(n-(k+1));
            end
            y(n) = y(n) + b(k+1)*c;
        end
    end
end
 %%
