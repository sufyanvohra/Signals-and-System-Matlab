 
 t = [0:0.001:1];
 n = mod(217010179,41);
 A = 3*rand(1,n);
 omega = pi*rand(1*n);
 xS = SUMCS(t,A,omega);
 xSReal = real(xS);
 xSimag = imag(xS);
 xSMa = abs(xS);
 xSangle = angle(xS);
 
 figure
 plot(t,xSReal);
 xlabel('t');
ylabel(' xSReal ');
title('Real Part of xS vs t');

 figure
 plot(t,xSimag);
 xlabel('t');
ylabel(' xSImag ');
title('Imaginary Part of xS vs t');

figure
plot(t,xSMa);
xlabel('t');
ylabel(' xSMa ' );
title('Magnitude of xS');

figure
plot(t,xSangle);
xlabel('t');
ylabel(' xSangle ');
title('Phase of xS');


function [xS] = SUMCS(t, A, omega)
M = length(A);
xS = 0;
for i= 1:M
    xS = xS + A(i).*exp(1j*(omega(i)/2).*t);
end
end

 
 

 