%% PART4
subplot(1,4,1);
x = ReadMyImage('Part4.bmp');
x1 = x - min(min(x));
subplot(2,2,1)
imshow(uint8(255*x1/max(max(abs(x1)))));
title("Original Image");
D = 21701079;
D17 = rem(D,17);
Mh = 20 + D17 ;
Nh = 20 + D17; 
B = [0.8 0.5 0.2];
for k = 1:3
    B_k = B(k);
    h = zeros(Mh,Nh);
    for m = 1:Mh
        for n = 1:Nh
            h(m,n) = sinc(B_k*(m-(Mh-1)/2)).*sinc(B_k*(n-(Nh-1)/2));
        end
    end
    filter_img = DSLSI2D(h,x);
    filter_img=filter_img-min(min(filter_img));
    subplot(2,2,k+1)
    imshow(uint8(255*filter_img/max(max(abs(filter_img)))));
    t = ['Filtered Image for B = ',num2str(B(k))];
    title(t);
end

%% part 5


x = ReadMyImage('Part5.bmp');
DisplayMyImage(x);
title("Original Image for part5");

h1 = [1 -1;-1 0];
h2 = [1 0;-1 0];
h3 = 0.5*h1 + 0.5*h2;
y1 = DSLSI2D(h1,x);
y2 = DSLSI2D(h2,x);
y3 = DSLSI2D(h3,x);

s1 = (y1.^2);
s2 = (y2.^2);
s3 = (y3.^2);
DisplayMyImage(s1);
title(" Image for s1 ")
DisplayMyImage(s2);
title(" Image for s2 ")
DisplayMyImage(s3);
title(" Image for s3 ")
%% 
imgX = ReadMyImage('Part6x.bmp');
DisplayMyImage(imgX);
title("Original Image for part6x ")
imgH = ReadMyImage('Part6h.bmp');
DisplayMyImage(imgH);
title("Original Image for part6h ")

y2 = DSLSI2D(imgH,imgX);
DisplayMyImage(abs(y2).^5);
title("Image with abs(y)^5");
%% part 3

function  y = DSLSI2D(h,x)
    sizeX = size(x);
    sizeH = size(h);
    Mx = sizeX(1);
    Nx = sizeX(2);
    Mh = sizeH(1);
    Nh = sizeH(2);
    y =zeros(Mx + Mh -1,Nx + Nh - 1);
    for k=0:Mh-1
        for l=0:Nh-1
            y(k+1:k+Mx,l+1:l+Nx)=y(k+1:k+Mx,l+1:l+Nx)+h(k+1,l+1)*x;
        end 
    end
end
    
    