
%% PART2
x = [8 1 6;3 5 7;4 9 2];
h = [1 3; 4 2];



function y = DSLSI2D(h,x)
    sizeX = size(x);
    sizeH = size(h);
    Mx = sizeX(1);
    Nx = sizeX(2);
    Mh = sizeH(1);
    Nh = sizeH(2);
    y =zeros(Mx + Mh -1,Nx + Nh - 1)
    for k=0:Mh-1
        for l=0:Nh-1
            y(k+1:k+Mx,l+1:l+Nx)=y(k+1:k+Mx,l+1:l+Nx)+h(k+1,l+1)*x;
        end 
    end
end


